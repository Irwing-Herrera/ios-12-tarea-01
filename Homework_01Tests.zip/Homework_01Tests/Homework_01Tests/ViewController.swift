//
//  ViewController.swift
//  Homework_01Tests
//
//  Created by C330593 on 07/03/24.
//

import UIKit

class ViewController: UIViewController {
    
    // MARK: - Variable Private
    
    private var stateRich: Bool = false
    
    // MARK: - Outlets
    
    @IBOutlet weak var catImageView: UIImageView!
    @IBOutlet weak var catLabel: UILabel!
    
    // MARK: - Actions
    
    @IBAction func stateCat(_ sender: Any) {
        
        let newValue = !self.stateRich
        
        if newValue {
            self.catRich()
        } else {
            self.catPoor()
        }
    }
    
    // MARK: - Life Cicle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.checkState()
    }

    // MARK: - Methods Private
    
    private func checkState() {
        if !self.stateRich {
            self.catPoor()
        } else {
            self.catRich()
        }
    }
    
    private func catRich() {
        self.changeText(rich: true)
        self.changeImage(rich: true)
        self.stateRich = true
    }
    
    private func catPoor() {
        self.changeText(rich: false)
        self.changeImage(rich: false)
        self.stateRich = false
    }
    
    private func changeText(rich: Bool) {
        if rich {
            DispatchQueue.main.async {
                self.catLabel.text = "Soy Rico"
            }
        } else {
            DispatchQueue.main.async {
                self.catLabel.text = "Soy Pobre"
            }
        }
    }
    
    private func changeImage(rich: Bool) {
        if rich {
            DispatchQueue.main.async {
                self.catImageView.image = UIImage(named:"rich.png")
            }
        } else {
            DispatchQueue.main.async {
                self.catImageView.image = UIImage(named:"poor.png")
            }
        }
    }
    

}

